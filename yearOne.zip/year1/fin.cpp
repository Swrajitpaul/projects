#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
   double line[10][26];
   ifstream fin;
   ofstream fout;
   fin.open("EC7.txt");
   fout.open("sc.txt");
   for (int i=0; i<10; i++) {
      for (int j=0; j<26; j++) {
         fin >> line[i][j];
      }
   }
   for (int i=0; i<1; i++) {
      for (int j=0; j<10; j++) {
         cout << line[i][j] << endl;
      }
   }
   fin.close();
   fout.close();
}


#include <iostream>
using namespace std;
int main () {
cout <<  "What is your command?" << endl;
return 0;
}

#include <iostream> 
using namespace std;
int main () { 
   cout << "How much tip do I pay?" << endl;
double amount;
cin >> (amount*.15);
return 0;
}

#include <iostream>
using namespace std;
int main () {
cout <<"Hi, there!" << endl;
cout << "Please enter your name.\n";
string name;
cin >> name;
cout <<"You entered: " << name << endl;
return 0;
}

#include <iostream>
using namespace std;
int main() {

/*
 
1) 1
2) 2
3) 4
4) -2

1) 7
2) 6
3) 7
4) 10

*/

int ten[10]; 
for (int i=0; i<10; i++) {
   cout << "enter array to be stored in" << i;
   cin >> ten[i];

#include <iostream>
#include <fstream>
using namespace std;

int main() {
   string line;
   ifstream fin;
   ofstream fout;
   fin.open("EC7.txt");
   fout.open("sc.txt");
   while (!fin.eof()) {
      int row=0;
      int col=0;
      while (getline(fin,line)) {
      
      }
      
   }
   /* for (int i=0; i<1; i++) {
      for (int j=0; j<10; j++) {
        cout << line[i][j] << endl;
      }
   } */
   cout << line << endl;
   fin.close();
   fout.close();
}

#include <iostream>
using namespace std;
int main() {
int hello;
hello = 0;
while (hello < 10) {
cout << "Hello ";
hello = hello +1;
if (hello == 10) {
cout << endl;
}
}


cout << "question 2" << endl;
int first =1;
while (first <=100) {
cout << first;
first = first+1;
if (first <=100) {
cout << endl;
}
}
return 0;
}

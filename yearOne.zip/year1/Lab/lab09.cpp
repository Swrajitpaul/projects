#include <iostream>
using namespace std;
int main () {
int positive;
cout << "Enter a positive number" << endl;
cin >> positive;
return 0;
}

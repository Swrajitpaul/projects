//Inline comment
//Name: Swrajit Paul
/*This is a block comment.
  Date: Feb 09, 2015
  Practice variables naming convention and arithmetics.
*/

//Fill in the blanks for the "standard ritual beginning" on the next 3 lines
#include <iostream>
using namespace std;
int  main ()     { 

	//Variable naming convention: which ones are legal below?
	int students211;
	int main3;
	string Captain_America, _Superman;
	string sp15;
	string return0;
	string who;

	//Correct the syntax errors below
	cout << "Welcome " "to CS111!" << endl;
	cout <<  "Let's program.\n";
	
	/*Print to the screen the message:
	  007 * 007 = 49
	*/
          cout << " 007 * 007= 49 " << endl;

	//Ask the user to enter their name.
        cout << "what is your name" << endl;
        cin >> who;
        

	//Print the square of 7.
	cout << 7 * 7 << endl;
	//Finish with the correct return statement
	return 0;
}

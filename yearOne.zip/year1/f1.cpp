#include <iostream>
using namespace std;
int main () {
	cout << "whats up" <<endl;
}

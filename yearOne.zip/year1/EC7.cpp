// Paul, swrajit

// INCOMPLETE EC7: I couldnt read the input file and put it in a array correctly! I knew how to find the hwSum and quizSum but it requires a correct array.

// thank you for a great semester, I will seek your help in the future if you dont mind.

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
   string line[10][26];
   ifstream fin;
   ofstream fout;
   fin.open("EC7.txt");
   fout.open("scoreSp15.txt");
   while (!fin.eof()) {
      int row=0;
      int col=0;
      while (getline(fin,line[row][col])) {
      col++;
      }
   
   row++;
   }
   int quizSum=0;
   int hwSum=0;
   for (int i=0; i<10; i++) {
      for (int j=0; j<10; j++) {
         fout<< line[i][j] <<endl;
      }
   }
   fin.close();
   fout.close();
}

public class Testrun {
	public static void main (String[] args) {
	System.out.print("hello "+ "swrajit");
	}
}
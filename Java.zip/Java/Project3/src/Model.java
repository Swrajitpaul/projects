import java.util.Observable;


public class Model extends Observable{
	Database data;
	String[] info;

	public Model(){
		
	}
	public void openDb(String filename){
		data = new Database(filename);
	}
	public void openTrans(String filename){
		
	}
	public void displayFruits(){
	}
}

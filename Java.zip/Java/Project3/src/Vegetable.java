
public class Vegetable extends ProduceItem{

	/**
	 * 
	 * @param cod takes in a string
	 * @param nam takes in a string
	 * @param pric takes in a string
	 */
	public Vegetable(String cod, String nam, String pric) {
		super(cod, nam, pric);
	}

}

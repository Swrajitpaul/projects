window.alert("The website is under construction")
